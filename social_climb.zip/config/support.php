<?php

return [
    'api_key' => env('API_KEY'),
];
