<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Detailed History</h3>
                    <p class="text-subtitle text-muted">View history</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">history</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <section id="multiple-column-form">
            <div class="row match-height">
                <div class="col-8">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"><?php echo e(strtoupper($History->username) .  ' (' . $History->created_at->diffForHumans() . ')'); ?></h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">

                                    <div class="row">
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="company-column">Transaction ID</label>
                                                <h4><?php echo e($History->reference); ?></h4>
                                            </div>
                                            <hr>
                                        </div>

                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="first-name-column">Network</label>
                                                <h4><?php echo e(strtoupper($History->network_id)); ?></h4>
                                            </div>
                                            <hr>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="last-name-column">Type</label>
                                                <h4><?php echo e($History->airtime_type); ?></h4>
                                            </div>
                                            <hr>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="first-name-column">Phone Number</label>
                                                <h4><?php echo e($History->mobile_number); ?></h4>
                                            </div><hr>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="city-column">Price</label>
                                                <h4><?php echo e($History->amount_paid); ?></h4>
                                            </div><hr>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="city-column">Status</label>
                                                <h4><?php echo e($History->status); ?></h4>
                                            </div><hr>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="country-floating">Medium</label>
                                                <h4><?php echo e($History->medium); ?></h4>
                                            </div>
                                        </div>
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="company-column">Balance Before</label>
                                                <h4><?php echo e($History->balance_before); ?></h4>
                                            </div><hr>
                                        </div>

                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="company-column">Balance After</label>
                                                <h4><?php echo e($History->balance_after); ?></h4>
                                            </div><hr>
                                        </div>

                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="company-column">Refund</label>
                                                <h4><?php echo e($History->refund ==1 ? 'Yes' : 'No'); ?></h4>
                                            </div><hr>
                                        </div>

                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="company-column">Response from API</label>
                                                <h4><?php echo e($History->api_response); ?></h4>
                                            </div><hr>
                                        </div>

                                        <div class="col-md-12 col-12 mb-10">
                                            <div class="form-group">
                                                <label for="company-column">Transaction Date</label>
                                                <h4><?php echo e(date('F d, Y', strtotime($History->created_at))); ?></h4>
                                            </div>
                                        </div>

                                    </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('components.base-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\SMARTROB\social_climb\resources\views/control/view-airtime-details.blade.php ENDPATH**/ ?>