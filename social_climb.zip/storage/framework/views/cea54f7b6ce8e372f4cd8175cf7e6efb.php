<?php $__env->startSection('content'); ?>
<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>View History</h3>
                <p class="text-subtitle text-muted">View User informations and history</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">User history</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
<section class="section">
    <div class="card">
        <div class="card-header">
            <?php echo e(strtoupper($User->username) . ' Fund History'); ?>

        </div>
        <div class="card-body">
            <table class="table table-striped" id="table1">
                <thead>
                    <tr>
                        <th>Amount</th>
                        <th>Reference</th>
                        <th>State</th>
                        <th>Channel</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $FHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(number_format($Fund->amount, 2)); ?></td>
                        <td><?php echo e($Fund->reference); ?></td>
                        <td>
                            <span class="badge <?php if($Fund->status =='active'): ?> <?php echo e('bg-success'); ?> <?php else: ?> <?php echo e('bg-danger'); ?> <?php endif; ?>"><?php echo e(Str::ucfirst($Fund->status)); ?></span>
                        </td>
                        <td> <?php echo e($Fund->payment_mode); ?> </td>
                        <td> <?php echo e($User->created_at); ?> </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>

</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.base-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\SMARTROB\social_climb\resources\views/control/user-history.blade.php ENDPATH**/ ?>