<?php $__env->startSection('content'); ?>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Bill Plans </h3>
                    <p class="text-subtitle text-muted">View and manage bill plans on the system</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">bill plans</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div id="error_result">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-dismissible fade show text-dark"
                    role="alert">
                    <strong class="text-white">Success! </strong> <span class="text-white">
                        <?php echo e(Session::get('success')); ?> </span>
                </div>
            <?php endif; ?>
            <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger text-danger alert-dismissible fade show"
                    role="alert">
                    <strong class="text-white ">Oh Oops! </strong> <span class="text-white">
                        <?php echo e(Session::get('fail')); ?> </span>
                </div>
            <?php endif; ?>
        </div>
        <section class="section">
            <div class="card">
                <div class="card-header">
                    Bill plan records
                    <a href="<?php echo e(route('create-bill')); ?>" class="btn btn-primary">Create New Plan</a>
                </div>
                <div class="card-body">
                    <table class="table table-striped" id="table1">
                        <thead>
                            <tr>
                                <th class="col">SN</th>
                                <th>Disco Name</th>
                                <th>Plan Name</th>
                                <th>Plan Code</th>
                                <th>Cost Price</th>
                                <th>Selling Price</th>
                                <th>Status</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $Pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $Price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($Price->disco_name); ?></td>
                                    <td><?php echo e($Price->plan_name); ?>

                                    <td><?php echo e($Price->plan_code); ?></td>
                                    <td><?php echo e(number_format($Price->cost_price, 2)); ?></td>
                                    <td><?php echo e(number_format($Price->plan_amount, 2)); ?></td>
                                    <td>
                                        <span
                                            class="badge <?php if($Price->is_active == 1): ?> bg-success <?php else: ?> bg-danger <?php endif; ?>">
                                            <?php echo e($Price->is_active == 1 ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e($Price->created_at); ?>

                                    </td>
                                    <td>
                                        <div class="btn-group mb-1">
                                            <div class="dropdown">
                                                <button class="btn btn-primary dropdown-toggle me-1" type="button"
                                                    id="dropdownMenuButtonIcon" data-bs-toggle="dropdown"
                                                    aria-haspopup="true" aria-expanded="false">
                                                    <i class="bi bi-error-circle me-50"></i> view more
                                                </button>
                                                <div class="dropdown-menu" aria-labelledby="dropdownMenuButtonIcon">
                                                    <a class="dropdown-item" href="/pricing/bill/<?php echo e($Price->id); ?>"
                                                        href=""> View</a>
                                                    <a class="dropdown-item" href="/bill/delete/<?php echo e($Price->id); ?>" confirm="Are you sure to delete this record ?">
                                                        Delete</a>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.base-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\SMARTROB\social_climb\resources\views/control/bill-plans.blade.php ENDPATH**/ ?>