<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Data Histories </h3>
                    <p class="text-subtitle text-muted">View and manage data histories on the system</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">data</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <div id="error_result">
            <?php if(Session::get('success')): ?>
                <div class="alert alert-success alert-dismissible fade show text-dark" role="alert">
                    <strong class="text-white">Success! </strong> <span class="text-white">
                        <?php echo e(Session::get('success')); ?> </span>
                </div>
            <?php endif; ?>
            <?php if(Session::get('fail')): ?>
                <div class="alert alert-danger text-danger alert-dismissible fade show" role="alert">
                    <strong class="text-white ">Oh Oops! </strong> <span class="text-white">
                        <?php echo e(Session::get('fail')); ?> </span>
                </div>
            <?php endif; ?>
        </div>
        <section class="section">
            <div class="card">
                <div class="card-header">
                    Data histories
                </div>
                <div class="card-body">
                    <table class="table table-striped" id="table1">
                        <thead>
                            <tr>
                                <th class="col">SN</th>
                                <th>Network</th>
                                <th>Plan</th>
                                <th>Username</th>
                                <th>Phone</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date Created</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $Histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $History): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><strong><?php echo e(strtoupper($History->network_id)); ?></strong></td>
                                    <td><span class="badge bg-primary"> <?php echo e($History->plan_size . ' ' . $History->plan_measure); ?> </span> </td>
                                    <td><strong><?php echo e($History->username); ?></strong></td>
                                    <td><strong><?php echo e($History->mobile_number); ?></strong></td>
                                    <td><?php echo e($History->plan_amount); ?></td>
                                    <td>
                                        <span
                                            class="badge <?php if($History->Status == 'success'): ?> bg-success <?php else: ?> bg-warning <?php endif; ?>">
                                            <?php echo e($History->Status); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <?php echo e(date('F d, Y', strtotime($History->created_at))); ?>

                                    </td>
                                    <td>
                                        <a href="/view-data-details/<?php echo e($History->id); ?>" class="btn btn-primary"> View more</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.base-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\SMARTROB\social_climb\resources\views/control/data-histories.blade.php ENDPATH**/ ?>