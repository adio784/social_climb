<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>View Plan</h3>
                    <p class="text-subtitle text-muted">View and update plan record</p>
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Plan View/Update</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>

        <section id="multiple-column-form">
            <div class="row match-height">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title"><?php echo e('Data plan table'); ?></h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <form action="<?php echo e(route('edit_airtime')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <div id="error_result">
                                        <?php if(Session::get('success')): ?>
                                            <div class="alert alert-success alert-dismissible fade show text-dark" role="alert">
                                                <strong class="text-white">Success! </strong> <span class="text-white"> <?php echo e(Session::get('success')); ?> </span>
                                            </div>
                                        <?php endif; ?>
                                        <?php if(Session::get('fail')): ?>
                                        <div class="alert alert-danger text-danger alert-dismissible fade show" role="alert">
                                            <strong class="text-white ">Oh Oops!  </strong> <span class="text-white"> <?php echo e(Session::get('fail')); ?> </span>
                                        </div>
                                        <?php endif; ?>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12 col-12">
                                            <div class="form-group">
                                                <label for="first-name-column">Network</label>
                                                <input type="hidden" name="plan_id" value="<?php echo e($Plan->id); ?>">
                                                <select class="form-control" name="network">
                                                    <?php $__currentLoopData = $Networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if($Network->id==1): ?> selected <?php endif; ?> value="<?php echo e($Network->id); ?>"><?php echo e($Network->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <?php $__errorArgs = ['network'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="city-column">Cost Percentage</label>
                                                <input type="text" id="city-column" name="cost_perc" class="form-control" value="<?php echo e($Plan->cost_perc); ?>">
                                            </div>
                                            <?php $__errorArgs = ['cost_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-6 col-12">
                                            <div class="form-group">
                                                <label for="city-column">Selling Percentage</label>
                                                <input type="text" id="city-column" name="selling_price" class="form-control" value="<?php echo e($Plan->percentage); ?>">
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-primary"> Submit </button>

                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('components.base-component', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\SMARTROB\social_climb\resources\views/control/airtimeperc.blade.php ENDPATH**/ ?>