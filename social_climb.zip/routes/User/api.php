<?php

use App\Http\Controllers\PaystackController;
use App\Http\Controllers\User\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/
Route::post('/create-account', [PaystackController::class, 'createdAccount']);
Route::post('/webhook/paystack', [PaystackController::class, 'handle']);

Route::post('/register', [AuthController::class, 'register'])->name('user.register');
Route::post('/login', [AuthController::class, 'login'])->name('user.login');
Route::post('/verify',  [AuthController::class, 'verify'])->name('user.verify');
Route::post('/password-reset', [AuthController::class, 'createPasswordReset'])->name('password-reset');
Route::post('/complete-password-reset', [AuthController::class, 'completeResetPassword'])->name('complete-password-reset');
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('log-out');
});
