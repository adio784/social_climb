<?php

namespace App\Services\User;

use App\Enums\TokenTypeEnum;
use App\Models\PaymentGateway;
use App\Models\User;
use App\Notifications\AccountActivatedNotification;
use App\Notifications\PasswordResetNotification;
use App\Notifications\RegisterNotification;
use App\Services\GatewayService;
use App\Services\PaystackService;
use App\Traits\ResponseTrait;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AuthService
{
    use ResponseTrait;

    public function __construct(protected User $user, protected GatewayService $gatewayService, protected PaystackService $paystackService)
    {
    }

    public function register(array $data)
    {
        try {
            $user = $this->user->create($data);
            $this->createActivation($user);
            $virtualAccData = [
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'middle_name' => $data['username'],
                'phone' => $data['phone'],
                'email' => $data['email'],
                'country' => 'NG',
                'preferred_bank' => 'test-paystack'
            ];
            $this->createVirtualAcc($virtualAccData);
            return $this->successResponse("User registered successfully. Please check your email to verify your account.", $user);
        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }

    public function login($data): JsonResponse
    {
        try {
            $user = $this->user->where('email', $data['email'])->first();
            if (!$user) {
                return $this->inputErrorResponse('Email address not recognized');
            }

            if (!Hash::check($data['password'], $user->password)) {
                return $this->inputErrorResponse("Invalid password");
            }
            if ($user && $this->checkActivation($user)) {
                $token = $user->createToken(config('auth.key'), ['guard' => 'user'])->plainTextToken;
                return $this->successResponse("Login successful", compact('user', 'token'));
            } else {
                throw new \Exception("Please verify your email");
            }
        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }

    public function update($data): JsonResponse
    {
        try {
            $user = DB::table('users')->where('email', $data['email'])->first();
            $user->update($data);
            return $this->successResponse("Update successful", compact('user', 'token'));

        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }


    public function createVirtualAcc(array $data)
    : JsonResponse
    {
        // check which payment gateway is set
        if ($this->gatewayService->getActiveGateway()->name === 'Strowallet') {
            // Create virtual account using strowallet
        } else {
            // Create virtual account using stro wallet
            try {
                $Dva = $this->paystackService->createVirtualAccount($data);
                return $Dva;
            } catch (Exception $ex) {
                Log::error($ex->getMessage());
                Log::error($ex->getTraceAsString());
                return $this->errorResponse($ex->getMessage());
            }
        }

    }


    public function createActivation($user, $type = TokenTypeEnum::EMAIL_VERIFICATION): void
    {

        $code = $this->generateCode();
        DB::table("operation_tokens")->insert([
            'user_id' => $user->id,
            'token' => $code,
            'type' => $type,
        ]);
        if ($type !== TokenTypeEnum::EMAIL_VERIFICATION) {
            $user->notify(new PasswordResetNotification($code));
        } else {
            $user->notify(new RegisterNotification($user, $code));
        }
    }

    public function generateCode(): string
    {
        return mt_rand(100000, 999999);
    }

    /**
     * Check if the user is logged in
     * @return mixed
     */
    public function check()
    {
        $check = auth('sanctum')->check();
        if ($check) {
            return true;
        }
        return false;
    }

    /**
     * @param $user
     * @return bool
     * Check if user account has been verified
     */
    public function checkActivation($user): bool
    {
        $completed = $user->email_verified_at;
        if ($completed === null) {
            $this->createActivation($user);
            return false;
        }
        return true;
    }

    /**
     * @param $user
     * @return bool
     * Check if user account has been verified
     */


    public function createAuthToken($user)
    {
        return $user->createToken('api-token')->plainTextToken;
    }

    public function getCurrentUser()
    {
        $check = auth('sanctum')->check();
        if ($check) {
            return auth('sanctum')->user();
        }
        return null;
    }

    /**
     * Log the user out of the application.
     * @return bool
     */
    public function logout()
    {
        $user = $this->getCurrentUser();
        $user->currentAccessToken()->delete();
        if ($user) {
            return $this->successResponse('Logout Successful');
        }
        return $this->errorResponse("No Logged in Session");
    }

    /**
     * Activate the given used id
     * @param int $userId
     * @param string $code
     * @return mixed
     */
    public function activate(array $data)
    {
        $code = $data['code'];
        $type = TokenTypeEnum::EMAIL_VERIFICATION;
        try {
            $codeModel = DB::table("operation_tokens")
                ->where('token', $code)
                ->where('completed', false)
                ->where('type', $type)
                ->first(['user_id', 'created_at', 'token']);
            // dd($codeModel->token);
            if ($codeModel && Carbon::parse($codeModel->created_at)) {
                // Token is valid and not expired
                DB::transaction(function () use ($codeModel) {
                    // Update the token to mark it as completed
                    DB::table("operation_tokens")
                        ->where('user_id', $codeModel->user_id)
                        ->where('token', $codeModel->token)
                        ->update([
                            'completed' => true,
                            'created_at' => Carbon::now() // Use updated_at for the update timestamp
                        ]);

                    // Update the user's email_verified_at field
                    $this->user->where('id', $codeModel->user_id)->update([
                        'email_verified_at' => Carbon::now(),
                    ]);
                });

                $user = $this->user->find($codeModel->user_id);
                $user->notify(new AccountActivatedNotification($user));
                return $this->successResponse("Account Verification Successful");
            } elseif ($codeModel) {
                // Token is either invalid or expired
                $userData = $this->user->find('id', $codeModel->user_id, []);
                $this->createActivation($userData);
                return $this->errorResponse(
                    "Unable to verify email. Either your account is already verified or an incorrect verification code was used. Please check your email for confirmation."
                );
            } else {
                // Token not found
                return false;
            }
        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }

    function expires(): Carbon
    {
        return Carbon::now()->subMinutes(60); // Example expiration time of 15 minutes
    }

    public function removeExpired(): bool
    {
        $expires = $this->expires();

        DB::table("operation_tokens")
            ->where('completed', false)
            ->where('created_at', '>', $expires)
            ->delete();
        return true;
    }

    public function createPasswordReset(array $data)
    {
        try {
            $user = $this->user->where('email', $data['email'])->first();
            $this->createActivation($user, TokenTypeEnum::PASSWORD_RESET);
            return $this->successResponse('Password Reset request. Please check your email to reset your password');
        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }

    /**
     * @throws Exception
     */
    public function completeResetPassword(array $data)
    {
        try {
            $user = $this->user->where('email', $data['email'])->first();
            if (Hash::check($data['password'], $user->password)) {
                throw new Exception("Please enter another password");
            }

            $code_model = DB::table("operation_tokens")->where('token', $data['code'])
                ->where('completed', false)
                ->where('created_at', '>', $this->expires());
            if (!$code_model) {
                throw new Exception("Please check your login details");
            }
            $user->update([
                'password' => Hash::make($data['password']),
            ]);
            DB::table("operation_tokens")
                ->where('token', $data['code'])
                ->update([
                    'completed' => true,
                    'updated_at' => Carbon::now()
                ]);

            if (!$code_model) {
                $userData = $this->user->where('email', $data['email'])->first();
                $userArrayData = [
                    'id' => $userData['id'],
                    'first_name' => $userData['first_name'],
                    'last_name' => $userData['last_name'],
                    'email' => $userData['email']
                ];
                $this->createActivation(json_encode($userArrayData), TokenTypeEnum::EMAIL_VERIFICATION);

                return false;
            }

            return false;
        } catch (Exception $ex) {
            Log::error($ex->getMessage());
            Log::error($ex->getTraceAsString());
            return $this->errorResponse($ex->getMessage());
        }
    }
}
