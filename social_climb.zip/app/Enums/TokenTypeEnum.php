<?php

namespace App\Enums;

enum TokenTypeEnum
{
    const EMAIL_VERIFICATION = 'EMAIL_VERIFICATION';
    const PASSWORD_RESET = 'PASSWORD_RESET';
}
