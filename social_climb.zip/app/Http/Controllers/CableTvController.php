<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CableTvController extends Controller
{
    //
}
