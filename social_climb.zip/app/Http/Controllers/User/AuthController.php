<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Requests\UserAuthRequest\ActivateAccountRequest;
use App\Http\Requests\UserAuthRequest\CompletePasswordResetRequest;
use App\Http\Requests\UserAuthRequest\LoginRequest;
use App\Http\Requests\UserAuthRequest\PasswordResetRequest;
use App\Http\Requests\UserAuthRequest\RegisterRequest;
use App\Services\User\AuthService;
use App\Traits\ResponseTrait;
use Illuminate\Http\JsonResponse;

class AuthController extends Controller
{
    use ResponseTrait;
    public function __construct(protected AuthService $authService)
    {
    }

    public function register(RegisterRequest $request): JsonResponse
    {
        return $this->authService->register($request->validated());
    }

    public function login(LoginRequest $request): JsonResponse
    {
        return $this->authService->login($request->validated());
    }

    public function verify(ActivateAccountRequest $request): JsonResponse
    {
        return $this->authService->activate($request->validated());
    }

    public function createPasswordReset(PasswordResetRequest $request): JsonResponse
    {
        return $this->authService->createPasswordReset($request->validated());
    }

    public function completeResetPassword(CompletePasswordResetRequest $request): JsonResponse
    {
        try {
            $this->authService->completeResetPassword($request->validated());
            return $this->successResponse('Password reset successful');
        } catch (\Exception $ex) {
            return $this->errorResponse($ex->getMessage(), "Something went wrong", 401);
        }
    }

    public function logout()
    {
        return $this->authService->logout();
    }
}
